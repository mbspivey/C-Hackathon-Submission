﻿namespace Project2___ArithmeticIsCool
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.startTextBox = new System.Windows.Forms.TextBox();
            this.endTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.resultListBox = new System.Windows.Forms.ListBox();
            this.absValButton = new System.Windows.Forms.Button();
            this.countButton = new System.Windows.Forms.Button();
            this.fibonacciButton = new System.Windows.Forms.Button();
            this.descSortButton = new System.Windows.Forms.Button();
            this.rangeButton = new System.Windows.Forms.Button();
            this.perimeterButton = new System.Windows.Forms.Button();
            this.pythButton = new System.Windows.Forms.Button();
            this.multiplyButton = new System.Windows.Forms.Button();
            this.factorialButton = new System.Windows.Forms.Button();
            this.exponentButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.sumSquaresButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // startTextBox
            // 
            this.startTextBox.Location = new System.Drawing.Point(23, 41);
            this.startTextBox.MaxLength = 9;
            this.startTextBox.Name = "startTextBox";
            this.startTextBox.Size = new System.Drawing.Size(87, 23);
            this.startTextBox.TabIndex = 2;
            this.startTextBox.Click += new System.EventHandler(this.startTextBox_Click);
            this.startTextBox.TextChanged += new System.EventHandler(this.startTextBox_TextChanged);
            this.startTextBox.Enter += new System.EventHandler(this.startTextBox_Enter);
            this.startTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.startTextBox_KeyPress);
            // 
            // endTextBox
            // 
            this.endTextBox.Location = new System.Drawing.Point(140, 41);
            this.endTextBox.MaxLength = 9;
            this.endTextBox.Name = "endTextBox";
            this.endTextBox.Size = new System.Drawing.Size(87, 23);
            this.endTextBox.TabIndex = 3;
            this.endTextBox.Click += new System.EventHandler(this.endTextBox_Click);
            this.endTextBox.TextChanged += new System.EventHandler(this.endTextBox_TextChanged);
            this.endTextBox.Enter += new System.EventHandler(this.endTextBox_Enter);
            this.endTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.endTextBox_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Start number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(137, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "End number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Result:";
            // 
            // resultListBox
            // 
            this.resultListBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultListBox.FormattingEnabled = true;
            this.resultListBox.ItemHeight = 15;
            this.resultListBox.Location = new System.Drawing.Point(23, 111);
            this.resultListBox.Name = "resultListBox";
            this.resultListBox.Size = new System.Drawing.Size(260, 169);
            this.resultListBox.TabIndex = 5;
            // 
            // absValButton
            // 
            this.absValButton.Location = new System.Drawing.Point(22, 295);
            this.absValButton.Name = "absValButton";
            this.absValButton.Size = new System.Drawing.Size(113, 67);
            this.absValButton.TabIndex = 6;
            this.absValButton.Text = "&Absolute Value";
            this.absValButton.UseVisualStyleBackColor = true;
            this.absValButton.Click += new System.EventHandler(this.absValButton_Click);
            // 
            // countButton
            // 
            this.countButton.Location = new System.Drawing.Point(170, 295);
            this.countButton.Name = "countButton";
            this.countButton.Size = new System.Drawing.Size(113, 67);
            this.countButton.TabIndex = 7;
            this.countButton.Text = "&Count";
            this.countButton.UseVisualStyleBackColor = true;
            this.countButton.Click += new System.EventHandler(this.countButton_Click);
            // 
            // fibonacciButton
            // 
            this.fibonacciButton.Location = new System.Drawing.Point(319, 295);
            this.fibonacciButton.Name = "fibonacciButton";
            this.fibonacciButton.Size = new System.Drawing.Size(113, 67);
            this.fibonacciButton.TabIndex = 8;
            this.fibonacciButton.Text = "F&ibonacci";
            this.fibonacciButton.UseVisualStyleBackColor = true;
            this.fibonacciButton.Click += new System.EventHandler(this.fibonacciButton_Click);
            // 
            // descSortButton
            // 
            this.descSortButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.descSortButton.Location = new System.Drawing.Point(319, 375);
            this.descSortButton.Name = "descSortButton";
            this.descSortButton.Size = new System.Drawing.Size(113, 67);
            this.descSortButton.TabIndex = 11;
            this.descSortButton.Text = "&Descending Sort";
            this.descSortButton.UseVisualStyleBackColor = true;
            this.descSortButton.Click += new System.EventHandler(this.descSortButton_Click);
            // 
            // rangeButton
            // 
            this.rangeButton.Location = new System.Drawing.Point(170, 375);
            this.rangeButton.Name = "rangeButton";
            this.rangeButton.Size = new System.Drawing.Size(113, 67);
            this.rangeButton.TabIndex = 10;
            this.rangeButton.Text = "&Range";
            this.rangeButton.UseVisualStyleBackColor = true;
            this.rangeButton.Click += new System.EventHandler(this.rangeButton_Click);
            // 
            // perimeterButton
            // 
            this.perimeterButton.Location = new System.Drawing.Point(22, 375);
            this.perimeterButton.Name = "perimeterButton";
            this.perimeterButton.Size = new System.Drawing.Size(113, 67);
            this.perimeterButton.TabIndex = 9;
            this.perimeterButton.Text = "&Perimeter";
            this.perimeterButton.UseVisualStyleBackColor = true;
            this.perimeterButton.Click += new System.EventHandler(this.perimeterButton_Click);
            // 
            // pythButton
            // 
            this.pythButton.Location = new System.Drawing.Point(170, 535);
            this.pythButton.Name = "pythButton";
            this.pythButton.Size = new System.Drawing.Size(113, 67);
            this.pythButton.TabIndex = 16;
            this.pythButton.Text = "P&ythagorean Theorem";
            this.pythButton.UseVisualStyleBackColor = true;
            this.pythButton.Click += new System.EventHandler(this.pythButton_Click);
            // 
            // multiplyButton
            // 
            this.multiplyButton.Location = new System.Drawing.Point(319, 455);
            this.multiplyButton.Name = "multiplyButton";
            this.multiplyButton.Size = new System.Drawing.Size(113, 67);
            this.multiplyButton.TabIndex = 14;
            this.multiplyButton.Text = "&Multiplication Table";
            this.multiplyButton.UseVisualStyleBackColor = true;
            this.multiplyButton.Click += new System.EventHandler(this.multiplyButton_Click);
            // 
            // factorialButton
            // 
            this.factorialButton.Location = new System.Drawing.Point(170, 455);
            this.factorialButton.Name = "factorialButton";
            this.factorialButton.Size = new System.Drawing.Size(113, 67);
            this.factorialButton.TabIndex = 13;
            this.factorialButton.Text = "&Factorial";
            this.factorialButton.UseVisualStyleBackColor = true;
            this.factorialButton.Click += new System.EventHandler(this.factorialButton_Click);
            // 
            // exponentButton
            // 
            this.exponentButton.Location = new System.Drawing.Point(22, 455);
            this.exponentButton.Name = "exponentButton";
            this.exponentButton.Size = new System.Drawing.Size(113, 67);
            this.exponentButton.TabIndex = 12;
            this.exponentButton.Text = "&Exponentiation";
            this.exponentButton.UseVisualStyleBackColor = true;
            this.exponentButton.Click += new System.EventHandler(this.exponentButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(319, 535);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(113, 67);
            this.exitButton.TabIndex = 17;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // sumSquaresButton
            // 
            this.sumSquaresButton.Location = new System.Drawing.Point(22, 535);
            this.sumSquaresButton.Name = "sumSquaresButton";
            this.sumSquaresButton.Size = new System.Drawing.Size(113, 67);
            this.sumSquaresButton.TabIndex = 15;
            this.sumSquaresButton.Text = "&Sum of Squares";
            this.sumSquaresButton.UseVisualStyleBackColor = true;
            this.sumSquaresButton.Click += new System.EventHandler(this.sumSquaresButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(289, 111);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(143, 157);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AcceptButton = this.absValButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(454, 624);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.sumSquaresButton);
            this.Controls.Add(this.pythButton);
            this.Controls.Add(this.multiplyButton);
            this.Controls.Add(this.factorialButton);
            this.Controls.Add(this.exponentButton);
            this.Controls.Add(this.descSortButton);
            this.Controls.Add(this.rangeButton);
            this.Controls.Add(this.perimeterButton);
            this.Controls.Add(this.fibonacciButton);
            this.Controls.Add(this.countButton);
            this.Controls.Add(this.absValButton);
            this.Controls.Add(this.resultListBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.endTextBox);
            this.Controls.Add(this.startTextBox);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "MainForm";
            this.Text = "arithmeticIsCool.org";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox startTextBox;
        private System.Windows.Forms.TextBox endTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox resultListBox;
        private System.Windows.Forms.Button absValButton;
        private System.Windows.Forms.Button countButton;
        private System.Windows.Forms.Button fibonacciButton;
        private System.Windows.Forms.Button descSortButton;
        private System.Windows.Forms.Button rangeButton;
        private System.Windows.Forms.Button perimeterButton;
        private System.Windows.Forms.Button pythButton;
        private System.Windows.Forms.Button multiplyButton;
        private System.Windows.Forms.Button factorialButton;
        private System.Windows.Forms.Button exponentButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button sumSquaresButton;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

