﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/*arithmeticIsCool.org
 * This app allows the user to input 2 numbers and apply to them a variety of mathematical 
 * functions: 
 * 
 * Absolute Value, Count, Fibonacci, Perimeter, Range, Decending Sort,
 * Exponentiation, Factorial, Multiplication Table, Prime, Pythagorean Theorem,
 * Standard Deviation, Sum of Squares, and a Wildcard Function (TBD).
 * 
 * The results of these functions are displayed in the listBox.
 * 
 * An exit button allows the user to close the app.
 * 
 * Authors: Matt Spivey, Aya Ayadi
 * Date: 10/25/2019
 */

namespace Project2___ArithmeticIsCool
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        //Global variables to store start and end numbers 
        int startNumber, endNumber;

        //Selects all values in textbox when tabbed into
        private void startTextBox_Enter(object sender, EventArgs e)
        {
            startTextBox.SelectAll();
        }

        //Selects all values in textbox when clicked into
        private void startTextBox_Click(object sender, EventArgs e)
        {
            startTextBox.SelectAll();
        }

        //clears listbox when textbox value is changed
        private void startTextBox_TextChanged(object sender, EventArgs e)
        {
            resultListBox.Items.Clear();
        }

        //Selects all values in textbox when tabbed into
        private void endTextBox_Enter(object sender, EventArgs e)
        {
            endTextBox.SelectAll();
        }

        //Selects all values in textbox when clicked into
        private void endTextBox_Click(object sender, EventArgs e)
        {
            endTextBox.SelectAll();
        }

        //clears listbox when textbox value is changed
        private void endTextBox_TextChanged(object sender, EventArgs e)
        {
            resultListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //exit with confirmation
            DialogResult dialog = MessageBox.Show("Are you sure you want to exit?",
           this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            //if yes, close
            if (dialog == DialogResult.Yes)
            {
                this.AutoValidate = AutoValidate.Disable;
                this.Close();
            }
        }

        /* Calculates and displays absolute value of both input values
         * Coded by: Matt
         * Reviewed by: Aya
         */
        private void absValButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {
                //call getInputs method to bring in textbox values
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();

                int absValStart, absValEnd;

                //find absolute value depending on if imputs are positive or negative
                if (startNumber >= 0)
                    absValStart = startNumber;
                else
                    absValStart = startNumber * -1;

                if (endNumber >= 0)
                    absValEnd = endNumber;
                else
                    absValEnd = endNumber * -1;

                //print to listbox
                resultListBox.Items.Add("The absolute value of " + startNumber + ": " + absValStart + ".");
                resultListBox.Items.Add("The absolute value of " + endNumber + ": " + absValEnd + ".");
            }
        }

        /* Counts and displays number of values betweem input values
         * Coded by: Matt
         * Reviewed by: Aya
         */
        private void countButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {
                //Get inputs
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();

                int count; //declare local variable

                count = startNumber - endNumber; //Calculation 

                //calculate count depending on whether current count calue is negative
                if (count <= 0)
                {
                    count = count * -1;
                    count = count + 1;
                }
                else
                    count = count + 1;

                //print to listbox
                resultListBox.Items.Add("Count of values between " + startNumber + " and " + endNumber + ": " + count);
            }
        }

        /* Treats start number and end number as a rectangle's length and width respectively.
         * Uses values to calculate the rectangle's perimiter.
         * Coded by: Matt
         * Reviewed by: Aya
         */
        private void perimeterButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {
                //get inputs
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();

                //error handle to ensure values are nonnegative and nonzero
                if (startNumber <= 0 || endNumber <= 0 || startNumber > endNumber)
                {
                    MessageBox.Show("Perimeter values cannot be negative or zero. " +
                        "Start number (width) must also be smaller than End number (length)." +
                        "Please try again.",
                        "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    startTextBox.Focus();
                    startTextBox.SelectAll();
                }
                else
                {
                    int perimeter;
                    //calculate perimeter
                    perimeter = (2 * startNumber) + (2 * endNumber);

                    //print to listbox
                    resultListBox.Items.Add("Rectangle perimeter: width = " + startNumber + "; length=  " + endNumber + " is " + perimeter);
                }
            }
        }

        /* Finds the exponential value when start number is the base number and end number is the exponent
         * Coded by: Aya
         * Reviewed by: Matt
         */
        private void exponentButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {

                //Get input
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();

                //Declare local variable
                double result;

                //Calculations
                result = Math.Pow(startNumber, endNumber);

                //print to listbox
                resultListBox.Items.Add(startNumber + " raised to the power of " + endNumber + ": " + result);
            }
        }

        /* Finds the range of all values between the two entered values, subtracting minimum number from maximum number
         * Coded by: Aya
         * Reviewed by: Matt
         */
        private void rangeButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {
                //Get input
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();

                //Declare variables
                int max, min, range;

                //If statement stating that the largest number has to be chosen between the start number and end number
                if (startNumber > endNumber)
                {
                    max = startNumber;
                    min = endNumber;
                }
                else
                {
                    max = endNumber;
                    min = startNumber;
                }

                range = max - min; //the range calcualtions

                //print to listbox
                resultListBox.Items.Add("Range of values between " + startNumber + " - " + endNumber + ": " + range);
            }
        }

        /* Lists the numbers between the start and end numbers inclusive in descending order
         * Coded by: Aya
         * Reviewed by: Matt
         */
        private void descSortButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {
                //get inputs
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();

                //Declare local variables  
                int min, max;

                //If statement stating that the largest number has to be chosen between the start number and end number
                if (startNumber > endNumber)
                {
                    max = startNumber;
                    min = endNumber;
                }
                else
                {
                    max = endNumber;
                    min = startNumber;
                }
                //For loops to present the results
                for (int iterations = max; iterations >= min; iterations--)
                {
                    resultListBox.Items.Add(iterations);
                }
            }
        }

        /* displays multiplication tables (1-12) for the start number entered by the user
         * Coded by: Aya
         * Reviewed by: Matt
         */
        private void multiplyButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values and clears end value if inputted 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {
                endTextBox.Clear();

                //Get input 
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();


                //Declare local variables 
                int result;

                //For loop to present the results
                for (int iterations = 1; iterations <= 12; iterations++)
                {
                    result = (iterations * startNumber);
                    resultListBox.Items.Add(iterations + " * " + startNumber + " = " + result);

                }
            }
        }

        /* displays the factorial value for the start number, diallowing negative values and values greater than 10
         * Coded by: Matt
         * Reviewed by: Aya
         */
        private void factorialButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values and clears end value if inputted 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            { 
                endTextBox.Clear();

            //Get inputs
            getInputs();

            //clear listbox
            resultListBox.Items.Clear();

                //If statement declaring an error if there is a number between 0 and 10 placed in teh start text
                if (startNumber > 10 || startNumber < 0)
                {
                    MessageBox.Show("Please enter a number between 0 and 10, inclusive.",
                        "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    startTextBox.Focus();
                    startTextBox.SelectAll();
                }
                else
                {

                    //Declaring local variable
                    int results = 1;

                    //For loop to display the result
                    for (int iteration = startNumber; iteration >= 1; iteration--)
                    {
                        results = results * iteration;
                    }
                    //print to list box
                    resultListBox.Items.Add(startNumber + "! = " + results);
                }
            }
        }
        /* displays the pythagorean theorem when start number = a and end number = b
         * Coded by: Matt
         * Reviewed by: Aya
         */
        private void pythButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {

                //Get inputs
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();

                //Declare local variables
                double a2, b2, c2, c;

                //Squaring the start number and end number 
                a2 = Math.Pow(startNumber, 2);
                b2 = Math.Pow(endNumber, 2);

                //Main equation for calculations
                c2 = a2 + b2;

                c = Math.Sqrt(c2);

                //print to list box
                resultListBox.Items.Add("a² + b² = c²");
                resultListBox.Items.Add(a2 + " + " + b2 + " = c²");
                resultListBox.Items.Add((a2 + b2) + " = c²");
                resultListBox.Items.Add(c + " = c");
            }
        }
        /* displays the start number squared and the end number squared, then the sum of both the start number and end number, plus the sum of both squared numbers
         * Coded by: Aya
         * Reviewed by: Matt
         */
        private void sumSquaresButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {
                //Get input 
                getInputs();

                //clear listbox
                resultListBox.Items.Clear();

                //If statement to create an error message when the number 0 is entered in the start text
                if (startNumber == 0 && endNumber == 0)
                {
                    MessageBox.Show("Please enter a number other than 0",
                        "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    startTextBox.Focus();
                    startTextBox.SelectAll();
                }
                else
                {
                    //Declaring local varibales 
                    double squaredOne, squaredTwo, result, resultSquared;

                    //Caluculations
                    squaredOne = Math.Pow(startNumber, 2);
                    squaredTwo = Math.Pow(endNumber, 2);
                    result = startNumber + endNumber;
                    resultSquared = squaredOne + squaredTwo;

                    //Get output
                    resultListBox.Items.Add("The number is: " + startNumber + " and its square is: " + squaredOne);
                    resultListBox.Items.Add("The number is: " + endNumber + " and its square is: " + squaredTwo);
                    resultListBox.Items.Add(" ");
                    resultListBox.Items.Add("Sum of numbers: " + result + " Sum of squares: " + resultSquared);

                }
            }
        }
        /* display the number of indexes of the fibonacci sequence equal to the start number
         * Coded by: Aya
         * Reviewed by: Matt
         */
        private void fibonacciButton_Click(object sender, EventArgs e)
        {
            //chacks for blank values and clears end value if inputted 
            if (startTextBox.Text == "" || endTextBox.Text == "")
            {
                MessageBox.Show("Start number and End number fields cannot be left blank.",
                "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                startTextBox.Focus();
                startTextBox.SelectAll();
            }
            else
            {
                endTextBox.Clear();

            //Get input
            getInputs();

            //clear listbox
            resultListBox.Items.Clear();

                //If statement to create an error message if a nuumber between 1 and 30 is entered in the start text
                if (startNumber < 0 || startNumber > 30)
                {
                    MessageBox.Show("Please enter a number between 1 and 30, inclusive.",
                        "Error Message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                    startTextBox.Focus();
                    startTextBox.SelectAll();
                }
                else
                {
                    resultListBox.Items.Add("Fibonacci sequence for " + startNumber + ":");

                    int[] fibonacci = new int[startNumber]; //creating array 

                    int index = 0; //declaring local variable 

                    for (int iteration = 0; iteration <= startNumber - 1; iteration++) //creating a for loop to list the numbers 
                        if (iteration == 0)
                        {
                            fibonacci[0] = 0; //starting the array with 0 
                            resultListBox.Items.Add(fibonacci[index]); //displaying the array 
                            index++;
                        }
                        else if (iteration == 1) //starting with the number 1 after the 0 
                        {
                            fibonacci[1] = 1;
                            resultListBox.Items.Add(fibonacci[index]);
                            index++;
                        }
                        else
                        {
                            //calculating the fibonacci equation
                            fibonacci[iteration] = fibonacci[iteration - 1] + fibonacci[iteration - 2];
                            resultListBox.Items.Add(fibonacci[iteration]);
                        }
                }
            }

        }

        private void startTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This event handler only allows digit, control characters, the negative symbol, and the period.
            if (!char.IsControl(e.KeyChar)
            && !char.IsDigit(e.KeyChar)
            && e.KeyChar != '-')
            {
                e.Handled = true;
                return;
            }

        }

        private void endTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This event handler only allows digit, control characters, the negative symbol, and the period.
            if (!char.IsControl(e.KeyChar)
            && !char.IsDigit(e.KeyChar)
            && e.KeyChar != '-')
            {
                e.Handled = true;
                return;
            }

        }

        private void getInputs()//get inputs 
        {
            //pull values from textboxes
            int.TryParse(startTextBox.Text, out startNumber);
            int.TryParse(endTextBox.Text, out endNumber);
        }
        

    }
}
